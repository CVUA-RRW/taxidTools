__version__ = "2.1.0"
__title__ = "taxidTools"
__description__ = "A Python Toolkit for Taxonomy"
__author__ = "Gregoire Denay"
__author_email__ = 'gregoire.denay@cvua-rrw.de'
__licence__ = 'BSD License'
__url__ = "https://github.com/CVUA-RRW/taxidTools"
